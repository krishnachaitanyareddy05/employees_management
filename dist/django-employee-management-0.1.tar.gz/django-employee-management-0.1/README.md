# Django Employee Management

A reusable Django app for managing employees.

## Installation

Install the package using pip: 
pip install django-employee-management

